package classes_abstratas;

public class Gato extends Animal{
	@Override
	public void fazerBarulho() {
		System.out.println("Miauu!");
	}
}
